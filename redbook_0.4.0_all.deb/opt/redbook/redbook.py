#!/usr/bin/env python3
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, Gio, GObject, GdkPixbuf, Gdk
import sqlite3, zipfile, json, csv, shutil, urllib.parse, html
from pathlib import Path
from datetime import date, datetime

try:
    import requests
except Exception:
    requests = None

APP_ID = "io.github.XPYROTRON.RedBook"
APP_NAME = "RedBook"
DATA_DIR = Path.home() / ".local" / "share" / "redbook"
COVER_DIR = DATA_DIR / "covers"
DB_PATH = DATA_DIR / "redbook.sqlite3"

SHELVES = [
    ("All", "view-grid-symbolic"),
    ("Want to Read", "emblem-favorite-symbolic"),
    ("Reading", "media-playback-start-symbolic"),
    ("Finished", "emblem-ok-symbolic"),
    ("Paused", "media-playback-pause-symbolic"),
    ("Abandoned", "process-stop-symbolic"),
    ("Owned", "x-office-address-book-symbolic"),
    ("Wishlist", "starred-symbolic"),
    ("Red Books", "color-select-symbolic"),
]
SHELF_NAMES = [s[0] for s in SHELVES if s[0] != "All"]

CSS = b"""
.large-title { font-size: 30px; font-weight: 900; }
.stat-number { font-size: 34px; font-weight: 900; }
.stat-card { padding: 22px; border-radius: 22px; }
.book-card { padding: 12px; border-radius: 20px; min-width: 190px; }
.book-title { font-weight: 800; font-size: 15px; }
.detail-title { font-size: 30px; font-weight: 900; }
.section-title { font-size: 18px; font-weight: 800; }
.editor-cover-box { padding: 14px; border-radius: 20px; }
.editor-heading { font-size: 24px; font-weight: 900; }
"""

def ensure_dirs():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    COVER_DIR.mkdir(parents=True, exist_ok=True)

class Database:
    def __init__(self):
        ensure_dirs()
        self.conn = sqlite3.connect(DB_PATH)
        self.conn.row_factory = sqlite3.Row
        self.setup()

    def setup(self):
        self.conn.execute("""
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            author TEXT DEFAULT '',
            isbn TEXT DEFAULT '',
            shelf TEXT DEFAULT 'Want to Read',
            series TEXT DEFAULT '',
            language TEXT DEFAULT '',
            publisher TEXT DEFAULT '',
            page_count INTEGER DEFAULT 0,
            description TEXT DEFAULT '',
            cover_path TEXT DEFAULT '',
            rating INTEGER DEFAULT 0,
            tags TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            start_date TEXT DEFAULT '',
            finished_date TEXT DEFAULT '',
            first_publish_year TEXT DEFAULT '',
            openlibrary_key TEXT DEFAULT '',
            created_at TEXT DEFAULT '',
            updated_at TEXT DEFAULT ''
        )
        """)
        columns = [r["name"] for r in self.conn.execute("PRAGMA table_info(books)").fetchall()]
        for col in ["first_publish_year", "openlibrary_key"]:
            if col not in columns:
                self.conn.execute(f"ALTER TABLE books ADD COLUMN {col} TEXT DEFAULT ''")
        self.conn.commit()

    def books(self, text="", shelf="All"):
        clauses, params = [], []
        if shelf and shelf != "All":
            clauses.append("shelf=?"); params.append(shelf)
        if text:
            q = f"%{text}%"
            clauses.append("(title LIKE ? OR author LIKE ? OR isbn LIKE ? OR tags LIKE ? OR series LIKE ? OR publisher LIKE ?)")
            params += [q, q, q, q, q, q]
        sql = "SELECT * FROM books"
        if clauses: sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY updated_at DESC, title COLLATE NOCASE"
        return self.conn.execute(sql, params).fetchall()

    def get(self, book_id):
        return self.conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()

    def counts(self):
        rows = self.conn.execute("SELECT shelf, COUNT(*) c FROM books GROUP BY shelf").fetchall()
        d = {r["shelf"]: r["c"] for r in rows}
        d["All"] = sum(d.values())
        d["Finished This Year"] = self.conn.execute("SELECT COUNT(*) c FROM books WHERE finished_date LIKE ?", (f"{date.today().year}-%",)).fetchone()["c"]
        return d

    def save(self, data, book_id=None):
        now = datetime.now().isoformat(timespec="seconds")
        fields = ["title","author","isbn","shelf","series","language","publisher","page_count","description","cover_path","rating","tags","notes","start_date","finished_date","first_publish_year","openlibrary_key"]
        payload = {k: data.get(k, "") for k in fields}
        payload["page_count"] = int(payload["page_count"] or 0)
        payload["rating"] = int(payload["rating"] or 0)
        if book_id:
            payload["updated_at"] = now
            self.conn.execute("UPDATE books SET " + ",".join([f"{k}=?" for k in payload]) + " WHERE id=?", list(payload.values()) + [book_id])
        else:
            payload["created_at"] = now
            payload["updated_at"] = now
            self.conn.execute(f"INSERT INTO books ({','.join(payload)}) VALUES ({','.join(['?']*len(payload))})", list(payload.values()))
        self.conn.commit()

    def delete(self, book_id):
        self.conn.execute("DELETE FROM books WHERE id=?", (book_id,))
        self.conn.commit()

    def backup(self, path):
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(DB_PATH, "redbook.sqlite3")
            z.writestr("manifest.json", json.dumps({"app": APP_NAME, "version": 4, "created_at": datetime.now().isoformat()}, indent=2))
            for p in COVER_DIR.glob("*"):
                if p.is_file(): z.write(p, f"covers/{p.name}")

    def restore(self, path):
        tmp = DATA_DIR / "_restore_tmp"
        if tmp.exists(): shutil.rmtree(tmp)
        tmp.mkdir(parents=True)
        with zipfile.ZipFile(path) as z: z.extractall(tmp)
        if not (tmp / "redbook.sqlite3").exists():
            raise RuntimeError("Invalid RedBook backup")
        self.conn.close()
        shutil.copy2(tmp / "redbook.sqlite3", DB_PATH)
        if (tmp / "covers").exists():
            COVER_DIR.mkdir(exist_ok=True)
            for p in (tmp / "covers").glob("*"):
                shutil.copy2(p, COVER_DIR / p.name)
        shutil.rmtree(tmp)
        self.conn = sqlite3.connect(DB_PATH)
        self.conn.row_factory = sqlite3.Row
        self.setup()

    def export_csv(self, path):
        rows = self.conn.execute("SELECT * FROM books ORDER BY title COLLATE NOCASE").fetchall()
        with open(path, "w", newline="", encoding="utf-8") as f:
            if not rows: return
            w = csv.DictWriter(f, fieldnames=rows[0].keys())
            w.writeheader()
            for r in rows: w.writerow(dict(r))

def clean_desc(v):
    return v.get("value", "") if isinstance(v, dict) else (v or "")

def safe_filename(text):
    return "".join(c for c in text.lower().replace(" ", "-") if c.isalnum() or c in "-_")[:96] or "book"

def download_cover(url, title):
    if not url or not requests: return ""
    try:
        r = requests.get(url, timeout=15)
        ctype = r.headers.get("content-type", "")
        if r.status_code == 200 and r.content and ("image" in ctype or len(r.content) > 1000):
            path = COVER_DIR / f"{safe_filename(title)}-{int(datetime.now().timestamp())}.jpg"
            path.write_bytes(r.content)
            return str(path)
    except Exception:
        pass
    return ""

def fetch_metadata(query):
    if not requests:
        raise RuntimeError("python3-requests is missing.")
    query = query.strip()
    if not query:
        raise RuntimeError("Enter a title or ISBN.")
    isbn_like = query.replace("-", "").replace(" ", "").isdigit()
    if isbn_like:
        r = requests.get(f"https://openlibrary.org/isbn/{urllib.parse.quote(query)}.json", timeout=15)
        if r.status_code != 200: raise RuntimeError("No Open Library ISBN result found.")
        d = r.json()
        authors = []
        for a in d.get("authors", [])[:4]:
            key = a.get("key")
            if key:
                ar = requests.get("https://openlibrary.org" + key + ".json", timeout=10)
                if ar.status_code == 200: authors.append(ar.json().get("name", ""))
        cover = d.get("covers", [None])[0] if d.get("covers") else None
        return {
            "title": d.get("title",""), "author": ", ".join([a for a in authors if a]),
            "isbn": query, "publisher": ", ".join(d.get("publishers", [])[:2]),
            "page_count": d.get("number_of_pages", 0) or 0,
            "description": clean_desc(d.get("description","")),
            "first_publish_year": d.get("publish_date",""),
            "openlibrary_key": d.get("works", [{}])[0].get("key","") if d.get("works") else "",
            "cover_url": f"https://covers.openlibrary.org/b/id/{cover}-L.jpg" if cover else f"https://covers.openlibrary.org/b/isbn/{urllib.parse.quote(query)}-L.jpg"
        }
    r = requests.get("https://openlibrary.org/search.json?" + urllib.parse.urlencode({"q": query, "limit": 1}), timeout=15)
    if r.status_code != 200: raise RuntimeError("Open Library search failed.")
    docs = r.json().get("docs", [])
    if not docs: raise RuntimeError("No matching book found.")
    d = docs[0]
    cover = d.get("cover_i")
    work_key = d.get("key", "")
    desc = ""
    if work_key:
        try:
            wr = requests.get("https://openlibrary.org" + work_key + ".json", timeout=10)
            if wr.status_code == 200:
                desc = clean_desc(wr.json().get("description",""))
        except Exception:
            pass
    return {
        "title": d.get("title",""), "author": ", ".join(d.get("author_name", [])[:4]),
        "isbn": d.get("isbn", [""])[0] if d.get("isbn") else "",
        "publisher": d.get("publisher", [""])[0] if d.get("publisher") else "",
        "page_count": d.get("number_of_pages_median", 0) or 0,
        "description": desc,
        "first_publish_year": str(d.get("first_publish_year","") or ""),
        "openlibrary_key": work_key,
        "cover_url": f"https://covers.openlibrary.org/b/id/{cover}-L.jpg" if cover else "",
    }

def img_for_path(path, w, h):
    if path and Path(path).exists():
        try:
            return GdkPixbuf.Pixbuf.new_from_file_at_scale(path, w, h, True)
        except Exception:
            return None
    return None

class BookEditor(Adw.Window):
    __gsignals__ = {"saved": (GObject.SignalFlags.RUN_FIRST, None, ())}

    def __init__(self, parent, db, book=None):
        super().__init__(transient_for=parent, modal=True)
        self.db, self.book = db, book
        self.cover_path = book["cover_path"] if book else ""
        self.openlibrary_key = book["openlibrary_key"] if book else ""
        self.set_title("Add Book" if not book else "Edit Book")
        self.set_default_size(980, 820)

        self.toast = Adw.ToastOverlay()
        self.set_content(self.toast)

        header = Adw.HeaderBar()
        load = Gtk.Button(label="Auto Load")
        load.set_icon_name("folder-download-symbolic")
        load.connect("clicked", self.lookup)
        save = Gtk.Button(label="Save")
        save.set_icon_name("document-save-symbolic")
        save.add_css_class("suggested-action")
        save.connect("clicked", self.save)
        header.pack_start(load)
        header.pack_end(save)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        root.append(header)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_vexpand(True)

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=22)
        outer.set_margin_top(22)
        outer.set_margin_bottom(24)
        outer.set_margin_start(24)
        outer.set_margin_end(24)
        scrolled.set_child(outer)
        root.append(scrolled)
        self.toast.set_child(root)

        title = Gtk.Label(label="Book details", xalign=0)
        title.add_css_class("editor-heading")
        outer.append(title)

        hero = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=24)
        hero.set_hexpand(True)
        outer.append(hero)

        cover_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        cover_box.add_css_class("editor-cover-box")
        cover_box.add_css_class("view")
        cover_box.set_valign(Gtk.Align.START)
        self.cover = Gtk.Image(pixel_size=240)
        self.cover.set_size_request(240, 350)
        cover_box.append(self.cover)
        hint = Gtk.Label(label="Cover is downloaded automatically when metadata is loaded.", wrap=True, xalign=0)
        hint.add_css_class("dim-label")
        hint.set_size_request(240, -1)
        cover_box.append(hint)
        hero.append(cover_box)

        form_col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        form_col.set_hexpand(True)
        hero.append(form_col)

        basic = Adw.PreferencesGroup(title="Metadata")
        basic.set_hexpand(True)
        self.title = Adw.EntryRow(title="Title")
        self.author = Adw.EntryRow(title="Author")
        self.isbn = Adw.EntryRow(title="ISBN or search term")
        self.series = Adw.EntryRow(title="Series")
        self.language = Adw.EntryRow(title="Language")
        self.publisher = Adw.EntryRow(title="Publisher")
        self.pages = Adw.EntryRow(title="Page Count")
        self.year = Adw.EntryRow(title="First Published / Publish Date")
        self.tags = Adw.EntryRow(title="Tags")
        for row in [self.title, self.author, self.isbn, self.series, self.language, self.publisher, self.pages, self.year, self.tags]:
            basic.add(row)
        form_col.append(basic)

        status = Adw.PreferencesGroup(title="Reading status")
        self.shelf = Adw.ComboRow(title="Shelf", model=Gtk.StringList.new(SHELF_NAMES))
        self.rating = Adw.ComboRow(title="Rating", model=Gtk.StringList.new(["0","1","2","3","4","5"]))
        self.start_date = Adw.EntryRow(title="Start Date YYYY-MM-DD")
        self.finished_date = Adw.EntryRow(title="Finished Date YYYY-MM-DD")
        for row in [self.shelf, self.rating, self.start_date, self.finished_date]:
            status.add(row)
        form_col.append(status)

        desc_group = Adw.PreferencesGroup(title="Book description")
        desc_frame = Gtk.Frame()
        desc_frame.set_hexpand(True)
        desc_frame.set_size_request(-1, 210)
        self.description = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD_CHAR)
        self.description.set_top_margin(12)
        self.description.set_bottom_margin(12)
        self.description.set_left_margin(12)
        self.description.set_right_margin(12)
        desc_frame.set_child(self.description)
        desc_group.add(desc_frame)
        outer.append(desc_group)

        notes_group = Adw.PreferencesGroup(title="My notes")
        notes_frame = Gtk.Frame()
        notes_frame.set_hexpand(True)
        notes_frame.set_size_request(-1, 210)
        self.notes = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD_CHAR)
        self.notes.set_top_margin(12)
        self.notes.set_bottom_margin(12)
        self.notes.set_left_margin(12)
        self.notes.set_right_margin(12)
        notes_frame.set_child(self.notes)
        notes_group.add(notes_frame)
        outer.append(notes_group)

        if book:
            self.populate(book)
        else:
            self.shelf.set_selected(0)
            self.refresh_cover()

    def tv_get(self, tv):
        buf = tv.get_buffer()
        s, e = buf.get_bounds()
        return buf.get_text(s, e, True)

    def tv_set(self, tv, text):
        tv.get_buffer().set_text(text or "")

    def refresh_cover(self):
        pix = img_for_path(self.cover_path, 240, 350)
        if pix:
            self.cover.set_from_pixbuf(pix)
        else:
            self.cover.set_from_icon_name("x-office-address-book-symbolic")

    def populate(self, b):
        mapping = [
            ("title","title"),("author","author"),("isbn","isbn"),("series","series"),
            ("language","language"),("publisher","publisher"),("pages","page_count"),
            ("year","first_publish_year"),("tags","tags"),("start_date","start_date"),
            ("finished_date","finished_date")
        ]
        for attr, col in mapping:
            getattr(self, attr).set_text(str(b[col] or ""))
        self.tv_set(self.description, b["description"])
        self.tv_set(self.notes, b["notes"])
        self.shelf.set_selected(SHELF_NAMES.index(b["shelf"]) if b["shelf"] in SHELF_NAMES else 0)
        self.rating.set_selected(max(0, min(5, int(b["rating"] or 0))))
        self.refresh_cover()

    def lookup(self, *_):
        try:
            q = self.isbn.get_text().strip() or self.title.get_text().strip()
            meta = fetch_metadata(q)
            for k, widget in [
                ("title", self.title), ("author", self.author), ("isbn", self.isbn),
                ("publisher", self.publisher), ("first_publish_year", self.year)
            ]:
                if meta.get(k):
                    widget.set_text(str(meta[k]))
            if meta.get("page_count"):
                self.pages.set_text(str(meta["page_count"]))
            if meta.get("description"):
                self.tv_set(self.description, meta["description"])
            self.openlibrary_key = meta.get("openlibrary_key", "")
            cover = download_cover(meta.get("cover_url", ""), meta.get("title") or self.title.get_text() or "book")
            if cover:
                self.cover_path = cover
                self.refresh_cover()
                self.toast.add_toast(Adw.Toast(title="Metadata and cover loaded"))
            else:
                self.toast.add_toast(Adw.Toast(title="Metadata loaded; no cover found"))
        except Exception as e:
            self.toast.add_toast(Adw.Toast(title=str(e)))

    def save(self, *_):
        if not self.title.get_text().strip():
            self.toast.add_toast(Adw.Toast(title="Title is required"))
            return
        data = {
            "title": self.title.get_text().strip(),
            "author": self.author.get_text().strip(),
            "isbn": self.isbn.get_text().strip(),
            "shelf": SHELF_NAMES[self.shelf.get_selected()],
            "series": self.series.get_text().strip(),
            "language": self.language.get_text().strip(),
            "publisher": self.publisher.get_text().strip(),
            "page_count": self.pages.get_text().strip() or "0",
            "description": self.tv_get(self.description),
            "cover_path": self.cover_path,
            "rating": self.rating.get_selected(),
            "tags": self.tags.get_text().strip(),
            "notes": self.tv_get(self.notes),
            "start_date": self.start_date.get_text().strip(),
            "finished_date": self.finished_date.get_text().strip(),
            "first_publish_year": self.year.get_text().strip(),
            "openlibrary_key": self.openlibrary_key,
        }
        self.db.save(data, self.book["id"] if self.book else None)
        self.emit("saved")
        self.close()

class DetailPage(Adw.Window):
    __gsignals__ = {"changed": (GObject.SignalFlags.RUN_FIRST, None, ())}

    def __init__(self, parent, db, book_id):
        super().__init__(transient_for=parent, modal=True)
        self.db, self.book_id = db, book_id
        self.set_title("Book")
        self.set_default_size(1060, 780)
        self.toast = Adw.ToastOverlay()
        self.set_content(self.toast)
        self.build()

    def label(self, txt, cls=None, wrap=True):
        l = Gtk.Label(label=txt or "", xalign=0, wrap=wrap, selectable=True)
        if cls:
            l.add_css_class(cls)
        return l

    def build(self):
        b = self.db.get(self.book_id)
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        header = Adw.HeaderBar()
        edit = Gtk.Button(label="Edit")
        edit.set_icon_name("document-edit-symbolic")
        edit.connect("clicked", self.edit)
        done = Gtk.Button(label="Mark Finished")
        done.set_icon_name("emblem-ok-symbolic")
        done.connect("clicked", self.mark_finished)
        delete = Gtk.Button(label="Delete")
        delete.set_icon_name("user-trash-symbolic")
        delete.add_css_class("destructive-action")
        delete.connect("clicked", self.delete)
        header.pack_start(delete)
        header.pack_end(done)
        header.pack_end(edit)
        root.append(header)

        sc = Gtk.ScrolledWindow()
        main = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=22, margin_top=24, margin_bottom=24, margin_start=28, margin_end=28)
        sc.set_child(main)
        root.append(sc)
        self.toast.set_child(root)

        hero = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=28)
        pix = img_for_path(b["cover_path"], 280, 410)
        img = Gtk.Image(pixel_size=280)
        img.set_size_request(280, 410)
        if pix:
            img.set_from_pixbuf(pix)
        else:
            img.set_from_icon_name("x-office-address-book-symbolic")
        hero.append(img)

        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        info.set_hexpand(True)
        info.append(self.label(b["title"], "detail-title"))
        info.append(self.label("by " + (b["author"] or "Unknown author"), "title-3"))
        stars = "★" * int(b["rating"] or 0) + "☆" * (5 - int(b["rating"] or 0))
        info.append(self.label(f"{b['shelf']}  ·  {stars}", "dim-label"))

        meta = []
        for label, col in [
            ("Series", "series"), ("Publisher", "publisher"), ("Published", "first_publish_year"),
            ("Language", "language"), ("Pages", "page_count"), ("ISBN", "isbn"),
            ("Started", "start_date"), ("Finished", "finished_date")
        ]:
            val = b[col]
            if val:
                meta.append(f"<b>{html.escape(label)}:</b> {html.escape(str(val))}")
        ml = Gtk.Label(xalign=0, wrap=True, use_markup=True, selectable=True)
        ml.set_markup("\n".join(meta) if meta else "No metadata yet.")
        info.append(ml)
        if b["tags"]:
            info.append(self.label("Tags: " + b["tags"], "dim-label"))
        hero.append(info)
        main.append(hero)

        for title, text in [
            ("Description", b["description"] or "No description yet. Click Edit → Auto Load."),
            ("My Notes", b["notes"] or "No notes yet.")
        ]:
            main.append(self.label(title, "section-title"))
            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, margin_top=8, margin_bottom=8, margin_start=12, margin_end=12)
            card.add_css_class("card")
            card.add_css_class("view")
            card.append(self.label(text))
            main.append(card)

    def edit(self, *_):
        d = BookEditor(self, self.db, self.db.get(self.book_id))
        d.connect("saved", lambda *_: (self.emit("changed"), self.close()))
        d.present()

    def mark_finished(self, *_):
        b = dict(self.db.get(self.book_id))
        b["shelf"] = "Finished"
        b["finished_date"] = date.today().isoformat()
        self.db.save(b, self.book_id)
        self.emit("changed")
        self.close()

    def delete(self, *_):
        self.db.delete(self.book_id)
        self.emit("changed")
        self.close()

class MainWindow(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app)
        self.db = Database()
        self.current_shelf = "All"
        self.set_title(APP_NAME)
        self.set_default_size(1280, 820)
        self.toast = Adw.ToastOverlay()
        self.set_content(self.toast)

        header = Adw.HeaderBar()
        title = Gtk.Label(label="RedBook")
        title.add_css_class("title-1")
        header.set_title_widget(title)

        add = Gtk.Button(label="Add Book")
        add.set_icon_name("list-add-symbolic")
        add.add_css_class("suggested-action")
        add.connect("clicked", self.add_book)
        header.pack_end(add)

        menu_btn = Gtk.MenuButton(icon_name="open-menu-symbolic")
        menu = Gio.Menu()
        menu.append("Backup Library", "app.backup")
        menu.append("Restore Backup", "app.restore")
        menu.append("Export CSV", "app.exportcsv")
        menu_btn.set_menu_model(menu)
        header.pack_end(menu_btn)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        root.append(header)

        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        paned.set_position(270)
        paned.set_vexpand(True)
        root.append(paned)
        self.toast.set_child(root)

        sidebar_sc = Gtk.ScrolledWindow()
        self.sidebar = Gtk.ListBox()
        self.sidebar.add_css_class("navigation-sidebar")
        self.sidebar.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.sidebar.connect("row-selected", self.shelf_selected)
        sidebar_sc.set_child(self.sidebar)
        paned.set_start_child(sidebar_sc)

        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14, margin_top=16, margin_bottom=16, margin_start=18, margin_end=18)
        paned.set_end_child(content)

        self.search = Gtk.SearchEntry(placeholder_text="Search books, authors, ISBN, tags, series")
        self.search.connect("search-changed", lambda *_: self.refresh_library())
        content.append(self.search)

        self.dashboard = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, column_spacing=14, row_spacing=14)
        self.dashboard.set_min_children_per_line(2)
        self.dashboard.set_max_children_per_line(5)
        content.append(self.dashboard)

        lib_title = Gtk.Label(label="Library", xalign=0)
        lib_title.add_css_class("large-title")
        content.append(lib_title)

        self.flow = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, column_spacing=18, row_spacing=18)
        self.flow.set_min_children_per_line(2)
        self.flow.set_max_children_per_line(7)
        self.flow.set_homogeneous(False)
        sc = Gtk.ScrolledWindow()
        sc.set_child(self.flow)
        sc.set_vexpand(True)
        content.append(sc)
        self.refresh_all()

    def refresh_all(self):
        self.refresh_sidebar()
        self.refresh_dashboard()
        self.refresh_library()

    def refresh_sidebar(self):
        while (child := self.sidebar.get_first_child()):
            self.sidebar.remove(child)
        counts = self.db.counts()
        selected_row = None
        for shelf, icon in SHELVES:
            row = Gtk.ListBoxRow()
            row.shelf = shelf
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10, margin_top=9, margin_bottom=9, margin_start=12, margin_end=12)
            box.append(Gtk.Image(icon_name=icon, pixel_size=18))
            label = Gtk.Label(label=shelf, xalign=0, hexpand=True)
            count = Gtk.Label(label=str(counts.get(shelf, 0)), xalign=1)
            count.add_css_class("dim-label")
            box.append(label)
            box.append(count)
            row.set_child(box)
            self.sidebar.append(row)
            if shelf == self.current_shelf:
                selected_row = row
        if selected_row:
            self.sidebar.select_row(selected_row)

    def shelf_selected(self, _box, row):
        if row:
            self.current_shelf = row.shelf
            self.refresh_library()

    def refresh_dashboard(self):
        while (child := self.dashboard.get_first_child()):
            self.dashboard.remove(child)
        counts = self.db.counts()
        cards = [
            ("All", counts.get("All",0), "view-grid-symbolic"),
            ("Want to Read", counts.get("Want to Read",0), "emblem-favorite-symbolic"),
            ("Reading", counts.get("Reading",0), "media-playback-start-symbolic"),
            ("Finished", counts.get("Finished",0), "emblem-ok-symbolic"),
            ("Finished This Year", counts.get("Finished This Year",0), "office-calendar-symbolic"),
            ("Red Books", counts.get("Red Books",0), "color-select-symbolic"),
        ]
        for shelf, value, icon in cards:
            btn = Gtk.Button()
            btn.add_css_class("flat")
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            box.add_css_class("stat-card")
            box.add_css_class("view")
            top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            top.append(Gtk.Image(icon_name=icon, pixel_size=22))
            top.append(Gtk.Label(label=shelf, xalign=0))
            num = Gtk.Label(label=str(value), xalign=0)
            num.add_css_class("stat-number")
            box.append(top)
            box.append(num)
            btn.set_child(box)
            btn.connect("clicked", lambda _b, s=("Finished" if shelf == "Finished This Year" else shelf): self.set_shelf(s))
            self.dashboard.append(btn)

    def set_shelf(self, shelf):
        self.current_shelf = shelf
        self.refresh_all()

    def refresh_library(self):
        while (child := self.flow.get_first_child()):
            self.flow.remove(child)
        books = self.db.books(self.search.get_text().strip(), self.current_shelf)
        if not books:
            empty = Gtk.Label(label="No books here yet. Click “Add Book” to start.", xalign=0)
            empty.add_css_class("dim-label")
            self.flow.append(empty)
            return
        for b in books:
            self.flow.append(self.book_card(b))

    def book_card(self, b):
        btn = Gtk.Button()
        btn.add_css_class("flat")
        btn.connect("clicked", lambda *_: self.open_detail(b["id"]))
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=9)
        card.add_css_class("book-card")
        card.add_css_class("view")
        img = Gtk.Image(pixel_size=176)
        img.set_size_request(176, 255)
        pix = img_for_path(b["cover_path"], 176, 255)
        if pix:
            img.set_from_pixbuf(pix)
        else:
            img.set_from_icon_name("x-office-address-book-symbolic")
        title = Gtk.Label(label=b["title"] or "Untitled", xalign=0, wrap=True, lines=2)
        title.add_css_class("book-title")
        author = Gtk.Label(label=b["author"] or "Unknown author", xalign=0, wrap=True, lines=1)
        author.add_css_class("dim-label")
        meta_text = b["shelf"]
        if b["finished_date"]:
            meta_text += " · " + b["finished_date"]
        rating = int(b["rating"] or 0)
        if rating:
            meta_text += " · " + ("★" * rating)
        meta = Gtk.Label(label=meta_text, xalign=0, wrap=True, lines=2)
        meta.add_css_class("caption")
        card.append(img)
        card.append(title)
        card.append(author)
        card.append(meta)
        btn.set_child(card)
        return btn

    def open_detail(self, book_id):
        d = DetailPage(self, self.db, book_id)
        d.connect("changed", lambda *_: self.refresh_all())
        d.present()

    def add_book(self, *_):
        d = BookEditor(self, self.db)
        d.connect("saved", lambda *_: self.refresh_all())
        d.present()

    def choose_save(self, title, name, cb):
        d = Gtk.FileDialog(title=title, initial_name=name)
        d.save(self, None, lambda dialog, res: self._save_done(dialog, res, cb))

    def _save_done(self, dialog, res, cb):
        try:
            f = dialog.save_finish(res)
            if f:
                cb(Path(f.get_path()))
        except Exception as e:
            self.toast.add_toast(Adw.Toast(title=str(e)))

    def choose_open(self, title, cb):
        d = Gtk.FileDialog(title=title)
        d.open(self, None, lambda dialog, res: self._open_done(dialog, res, cb))

    def _open_done(self, dialog, res, cb):
        try:
            f = dialog.open_finish(res)
            if f:
                cb(Path(f.get_path()))
        except Exception as e:
            self.toast.add_toast(Adw.Toast(title=str(e)))

class RedBookApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)

    def do_startup(self):
        Adw.Application.do_startup(self)
        provider = Gtk.CssProvider()
        provider.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        for name, fn in [("backup", self.backup), ("restore", self.restore), ("exportcsv", self.export_csv)]:
            act = Gio.SimpleAction.new(name, None)
            act.connect("activate", fn)
            self.add_action(act)

    def do_activate(self):
        win = self.props.active_window
        if not win:
            win = MainWindow(self)
        win.present()

    def backup(self, *_):
        w = self.props.active_window
        w.choose_save("Save RedBook Backup", f"redbook-{date.today().isoformat()}.redbook-backup", lambda p: (w.db.backup(p), w.toast.add_toast(Adw.Toast(title="Backup saved"))))

    def restore(self, *_):
        w = self.props.active_window
        def do_restore(p):
            w.db.restore(p)
            w.refresh_all()
            w.toast.add_toast(Adw.Toast(title="Backup restored"))
        w.choose_open("Restore RedBook Backup", do_restore)

    def export_csv(self, *_):
        w = self.props.active_window
        w.choose_save("Export CSV", f"redbook-{date.today().isoformat()}.csv", lambda p: (w.db.export_csv(p), w.toast.add_toast(Adw.Toast(title="CSV exported"))))

def main():
    return RedBookApp().run(None)

if __name__ == "__main__":
    raise SystemExit(main())
